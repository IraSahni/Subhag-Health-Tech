package com.studentProblemResolve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubhahHealthTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
