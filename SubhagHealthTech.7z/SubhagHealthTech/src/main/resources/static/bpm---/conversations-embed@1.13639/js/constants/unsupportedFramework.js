"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.METHODS = void 0;
const METHODS = [Object.prototype.toJSON, Array.prototype.toJSON, String.prototype.toJSON];
exports.METHODS = METHODS;