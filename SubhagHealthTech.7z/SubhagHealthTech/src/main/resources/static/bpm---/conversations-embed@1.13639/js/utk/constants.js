"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.USER_TOKEN_KEY = void 0;
const USER_TOKEN_KEY = '__hsUserToken';
exports.USER_TOKEN_KEY = USER_TOKEN_KEY;