"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WIDGET_LOCATION = void 0;
const WIDGET_LOCATION = 'widgetLocation';
exports.WIDGET_LOCATION = WIDGET_LOCATION;