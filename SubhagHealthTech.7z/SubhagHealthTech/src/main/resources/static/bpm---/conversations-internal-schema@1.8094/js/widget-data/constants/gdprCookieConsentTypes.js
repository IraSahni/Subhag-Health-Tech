"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ON_EXIT_INTENT = exports.ON_WIDGET_LOAD = exports.NEVER = void 0;
const NEVER = 'NEVER';
exports.NEVER = NEVER;
const ON_WIDGET_LOAD = 'ON_WIDGET_LOAD';
exports.ON_WIDGET_LOAD = ON_WIDGET_LOAD;
const ON_EXIT_INTENT = 'ON_EXIT_INTENT';
exports.ON_EXIT_INTENT = ON_EXIT_INTENT;